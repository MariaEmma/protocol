<?php
$lang['upload_no_file_selected'] = '';


/* End of file db_lang.php */
/* Location: ./application/language/english/db_lang.php */
