<?php
$data['base_url'] = $this->config->item('base_url'); 
$data['resources']= $this->config->item('resources');
?>

