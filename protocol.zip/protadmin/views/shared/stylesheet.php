	<!-- BOOTSTRAP STYLES-->
    <link href="<?php echo $resources;?>css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="<?php echo $resources;?>css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo $resources;?>css/chosen.css" rel="stylesheet" />
    <link href="<?php echo $resources;?>css/jquery.dynatable.css" rel="stylesheet" />
    <link href="<?php echo $resources;?>css/datepicker.css" rel="stylesheet" />
    <link href="<?php echo $resources;?>css/bootstrap-editable.css" rel="stylesheet"/>
         <!-- MORRIS CHART STYLES-->
   <!-- <link href="<?php //echo $resources;?>/js/morris/morris-0.4.3.min.css" rel="stylesheet" /> -->
     <!-- CUSTOM STYLES-->
    <link href="<?php echo $resources;?>css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
     <!-- TABLE STYLES-->
    <link href="<?php echo $resources;?>js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
     