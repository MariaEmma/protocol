<?php

$lang['required']= 'Απαιτείται να εισάγετε τιμή';
$lang['valid_email'] = 'Βάλτε σωστή ηλ. διεύθυνση'; 
$lang['xss_clean'] = 'Μη απόδεκτή τιμή';
$lang['max_length'] = 'Πρόβλημα με το ανώτατο αριθμό χαρακτήρων';
$lang['min_length'] = 'Πρόβλημα με το κατώτατο αριθμό χαρακτήρων';
$lang['is_unique'] = 'Η τιμή που εισάγετε υπάρχει ήδη'; 
$lang['numeric'] = 'Το πεδίο δέχεται αριθμητικά δεδομένα'; 
$lang['matches'] = 'Οι τιμές στα παρακάτω πεδία δεν συμφωνούν';
$lang['edit_unique'] = 'Η τιμή που εισάγετε υπάρχει ήδη';
/* End of file form_validation_lang.php */
/* Location: ./application/language/english/datamapper_lang.php */
