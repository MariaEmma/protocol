<?php
define('MY_IMAGEPATH',$_SERVER['DOCUMENT_ROOT'].'/assets/img/');
define('MY_FILEPATH',$_SERVER['DOCUMENT_ROOT'].'/assets/uploads/files/');

define('MY_IMAGEFOLDER',$this->config->item('resources').'img/');
define('MY_FILEFOLDER',$this->config->item('resources').'uploads/files/');

