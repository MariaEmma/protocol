<?php



/* End of file db_lang.php */
/* Location: ./application/language/english/db_lang.php */
