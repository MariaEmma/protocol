<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12"><h4>Βρίσκεστε: <span style="color:green;"><?php echo $mtitle;?></span></h4> 
                <?php echo $this->session->flashdata('msg'); ?>
                <div class="panel panel-default">
                    
                    <div class="panel-heading">Αίτημα για πρωτοκόληση
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <div id="dataTables-files_wrapper" class="dataTables_wrapper form-inline" role="grid">
                                <?php $attributes = array('id' => 'requestnewform'); ?>
                                <?php echo form_open('backend/suser/request/'.$ontotita->id, $attributes); ?>
                              
                        <div class="form-group">
                            <?php if(isset($_POST['description'])) $set1 = $_POST['description']; else $set1='';?>
                                <?php echo form_error('description');?> 
                                <?php echo form_label('Θέμα', 'description', array(
                                    'for' => 'description',
                                    ));  ?>
                                <?php echo form_textarea(array(
                                    'name'        => 'description',
                                    'id'          => 'description',
                                    'tabindex'    => '1',
                                    'value'       => $set1,
                                    'placeholder' => 'Εισάγετε Θέμα',
                                    'class'       => 'form-control',
                                    'rows'        => '2'
                                 ));?>
                        </div>
 
<?php echo form_button(array(
                                        'name' => 'button',
                                        'id' => 'button',
                                        'value' => 'true',
                                        'tabindex'    => '2',
                                        'type' => 'submit',
                                        'content' => 'Αποστολή',
                                        'class' => 'btn btn-danger'
)); ?>
                                               

<?php echo form_close();?> 
                                 
                            </div>
                        </div>
                    </div>
                </div>

            </div>    
        </div>

    </div><!--page inner end-->
    
</div><!--page wrapper end-->