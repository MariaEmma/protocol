<?php

$lang['autoform_confirm_field'] = 'confirm_%field%';
$lang['autoform_confirm_label'] = 'Confirm %field%';

$lang['autoform_reset_label'] = 'Reset';

$lang['autoform_submit_button'] = 'submit';
$lang['autoform_submit_label'] = 'Submit';

$lang['autoform_password_label'] = 'Password';